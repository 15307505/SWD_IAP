#ifndef __SLEEP_H_
#define __SLEEP_H_

#include "stm32f10x.h"


void Rtc_Init(void);

void TestStopMode(void);
void EXTI_Configuration(void);
void TIM3_Int_Init(u16 arr,u16 psc);

void RCC_Configuration(void);

#endif


