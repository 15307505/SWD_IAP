#include "rtc.h"
#include "sys.h"


//void Rtc_Init(void)
//{
//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

//	PWR_BackupAccessCmd(ENABLE);

//	BKP_DeInit();

//	RCC_LSICmd(ENABLE);

//	while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET){}

//	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);

//	RCC_RTCCLKCmd(ENABLE);

//	RTC_WaitForSynchro();

//	RTC_WaitForLastTask();

//	RTC_ITConfig(RTC_IT_SEC, DISABLE);

//	RTC_WaitForLastTask();

//	RTC_SetPrescaler(40000);

//	RTC_WaitForLastTask();	
//	
//	RTC_SetCounter(0x00);
//	
//	RTC_WaitForLastTask();
//}

//void RTC_IRQHandler(void)
//{
//  if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
//  {
//		RTC_ClearITPendingBit(RTC_IT_SEC);
//  } 
//}






