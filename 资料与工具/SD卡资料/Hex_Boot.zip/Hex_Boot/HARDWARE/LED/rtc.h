#ifndef __TIMEBASE_H
#define __TIMEBASE_H

//#include "stm32f10x_rtc.h"
//#include "stm32f10x_bkp.h"


//void Rtc_Init(void);



#endif
