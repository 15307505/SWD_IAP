#include "sleep.h"

#include "stm32f10x_rcc.h"
#include "stm32f10x_pwr.h"
#include "stm32f10x_bkp.h"
#include "stm32f10x_rtc.h"

#include "usart.h"

void TestStopMode(void)
{
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
	
	RTC_SetCounter(0x00);
	RTC_WaitForLastTask();
	RTC_SetAlarm(RTC_GetCounter()+4); 
	RTC_WaitForLastTask();	
	RTC_ITConfig(RTC_IT_ALR, ENABLE);
	RTC_WaitForLastTask();
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
	PWR_EnterSTOPMode(PWR_Regulator_LowPower,PWR_STOPEntry_WFI|PWR_STOPEntry_WFE);	//����͹��ģ��жϻ���
}

void EXTI_Configuration(void)
{
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Configure EXTI Line17(RTC Alarm) to generate an interrupt on rising edge */
	EXTI_ClearITPendingBit(EXTI_Line17);
	EXTI_InitStructure.EXTI_Line = EXTI_Line17;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = RTCAlarm_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void RTCAlarm_IRQHandler(void)
{
  if(RTC_GetITStatus(RTC_IT_ALR) != RESET)
  {
    EXTI_ClearITPendingBit(EXTI_Line17);

    if(PWR_GetFlagStatus(PWR_FLAG_WU) != RESET)
    {
      PWR_ClearFlag(PWR_FLAG_WU);
    }
    RTC_WaitForLastTask();   
    RTC_ClearITPendingBit(RTC_IT_ALR);
    RTC_WaitForLastTask();
	USART_ClearITPendingBit(USART1, USART_IT_RXNE);	
	SystemInit();					//��ʼ��ʱ�ӣ��ж�������SCB->VTOR = FLASH_BASE | VECT_TAB_OFFSET;
	RCC->APB2ENR |= 0x1FD;      	//��������ʱ��AFIO��ABCDEFGʱ��
  }
}

void Rtc_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

	PWR_BackupAccessCmd(ENABLE);

	BKP_DeInit();

	RCC_LSICmd(ENABLE);

	while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET){}

	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);

	RCC_RTCCLKCmd(ENABLE);

	RTC_WaitForSynchro();

	RTC_WaitForLastTask();

	RTC_ITConfig(RTC_IT_SEC, DISABLE);

	RTC_WaitForLastTask();

	RTC_SetPrescaler(40000);

	RTC_WaitForLastTask();	
	
	RTC_SetCounter(0x00);
	
	RTC_WaitForLastTask();
}

void RTC_IRQHandler(void)
{
  if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
  {
		RTC_ClearITPendingBit(RTC_IT_SEC);
  } 
}


