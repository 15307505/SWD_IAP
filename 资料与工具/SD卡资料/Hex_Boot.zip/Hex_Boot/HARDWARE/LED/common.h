#ifndef  __COMMON_H
#define  __COMMON_H

#include   	<stdarg.h>
#include   	<stdio.h>
#include   	<stdlib.h>
#include   	<math.h>

#include 	"sys.h"
#include 	"stm32f10x_conf.h"


#include   	"ff.h"
#include 	"diskio.h"




#endif 
