#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "iap.h"


int main(void)
{
	
	__enable_irq();	
	SCB->VTOR = FLASH_BASE;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init();	   				 	//��ʱ������ʼ��
	uart_init(115200);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);	
	
	printf("System init is ok\r");
	
	BootToAPP();
	
}
